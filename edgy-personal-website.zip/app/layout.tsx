import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Playfair_Display, Roboto_Condensed } from "next/font/google"

// Load Playfair Display font
const playfairDisplay = Playfair_Display({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-playfair",
})

// Load Roboto Condensed font
const robotoCondensed = Roboto_Condensed({
  subsets: ["latin"],
  weight: ["300", "400", "700"],
  variable: "--font-roboto-condensed",
})

export const metadata: Metadata = {
  title: "Samantha Quintero | Graphic Designer • Illustrator • Artist",
  description: "Personal portfolio website showcasing graphic design, illustration, and artistic works",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`scroll-smooth ${playfairDisplay.variable} ${robotoCondensed.variable}`}>
      <body className="bg-black antialiased">{children}</body>
    </html>
  )
}



import './globals.css'