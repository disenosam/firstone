"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { motion, useScroll, useTransform } from "framer-motion"
import { Navigation } from "@/components/navigation"
import { GlitchEffect } from "@/components/glitch-effect"
import { TextDistortion } from "@/components/text-distortion"
import { FilmGrain } from "@/components/film-grain"
import { About } from "@/components/about"
import { Portfolio } from "@/components/portfolio"
import { Contact } from "@/components/contact"

export default function Home() {
  const { scrollY } = useScroll()
  const opacity = useTransform(scrollY, [0, 300], [1, 0])
  const scale = useTransform(scrollY, [0, 300], [1, 1.1])
  const heroRef = useRef<HTMLDivElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Simulate loading delay for dramatic effect
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <main className="relative min-h-screen bg-black text-bone-white overflow-hidden">
      <FilmGrain />

      {/* Hero Section */}
      <div ref={heroRef} className="relative h-screen flex items-center justify-center overflow-hidden">
        <motion.div className="absolute inset-0 z-0" style={{ opacity, scale }}>
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Hero Image"
            fill
            className="object-cover grayscale contrast-125 brightness-75"
            priority
          />
          <div className="absolute inset-0 bg-black/30 mix-blend-color-burn" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: isLoaded ? 1 : 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="relative z-10 container mx-auto px-4 text-center"
        >
          <GlitchEffect>
            <h1 className="font-serif text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter mb-6 text-bone-white">
              SAMANTHA
            </h1>
          </GlitchEffect>
          <TextDistortion>
            <p className="font-sans-condensed text-xl md:text-2xl uppercase tracking-widest text-wine-red">
              Graphic Designer • Illustrator • Artist
            </p>
          </TextDistortion>
        </motion.div>

        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 z-10">
          <motion.div
            initial={{ y: -10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1, delay: 1.5, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
            className="text-bone-white/70 font-sans-condensed text-sm tracking-widest"
          >
            SCROLL DOWN
          </motion.div>
        </div>
      </div>

      <Navigation />
      <About />
      <Portfolio />
      <Contact />
    </main>
  )
}

