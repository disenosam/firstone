"use client"

import { useState } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { Menu, X } from "lucide-react"

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  const menuItems = [
    { name: "HOME", href: "#" },
    { name: "ABOUT", href: "#about" },
    { name: "PORTFOLIO", href: "#portfolio" },
    { name: "CONTACT", href: "#contact" },
  ]

  const toggleMenu = () => setIsOpen(!isOpen)

  return (
    <>
      <div className="fixed top-0 left-0 w-full z-50 mix-blend-difference">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <Link
            href="#"
            className="font-serif text-2xl text-bone-white hover:text-wine-red transition-colors duration-300"
          >
            S.Q.
          </Link>
          <button
            onClick={toggleMenu}
            className="text-bone-white hover:text-wine-red transition-colors duration-300 z-50"
            aria-label={isOpen ? "Close menu" : "Open menu"}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="fixed inset-0 bg-black/95 z-40 flex items-center justify-center"
          >
            <motion.nav
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-center"
            >
              <ul className="space-y-8">
                {menuItems.map((item, index) => (
                  <motion.li
                    key={item.name}
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.1 * index + 0.3 }}
                  >
                    <Link
                      href={item.href}
                      onClick={toggleMenu}
                      className="font-serif text-4xl md:text-6xl text-bone-white hover:text-wine-red transition-colors duration-300 relative group"
                    >
                      {item.name}
                      <span className="absolute -bottom-2 left-0 w-0 h-0.5 bg-wine-red transition-all duration-300 group-hover:w-full"></span>
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

