"use client"

import type React from "react"

import { useState, useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Instagram, Mail, Send, Dribbble, DribbbleIcon as Behance } from "lucide-react"

export function Contact() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, amount: 0.3 })
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormState({
      ...formState,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Form submission logic would go here
    console.log(formState)
    alert("Message sent successfully!")
    setFormState({ name: "", email: "", message: "" })
  }

  return (
    <section id="contact" className="py-24 md:py-32 relative">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
            transition={{ duration: 0.8 }}
            className="space-y-12"
          >
            <h2 className="font-serif text-4xl md:text-6xl text-bone-white mb-12 relative inline-block">
              CONTACT
              <span className="absolute -bottom-2 left-0 w-1/3 h-0.5 bg-wine-red"></span>
            </h2>

            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-8">
                <p className="font-sans-condensed text-lg text-bone-white/90">
                  Interested in collaborating or commissioning a design project? Send me a message and let's create
                  something extraordinary together.
                </p>

                <div className="space-y-4">
                  <a
                    href="mailto:contact@samanthaquintero.com"
                    className="flex items-center gap-3 font-sans-condensed text-bone-white hover:text-wine-red transition-colors duration-300"
                  >
                    <Mail size={20} />
                    <span>contact@samanthaquintero.com</span>
                  </a>
                  <a
                    href="https://instagram.com/samanthaquintero"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 font-sans-condensed text-bone-white hover:text-wine-red transition-colors duration-300"
                  >
                    <Instagram size={20} />
                    <span>@samanthaquintero</span>
                  </a>
                  <a
                    href="https://dribbble.com/samanthaquintero"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 font-sans-condensed text-bone-white hover:text-wine-red transition-colors duration-300"
                  >
                    <Dribbble size={20} />
                    <span>dribbble.com/samanthaquintero</span>
                  </a>
                  <a
                    href="https://behance.net/samanthaquintero"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 font-sans-condensed text-bone-white hover:text-wine-red transition-colors duration-300"
                  >
                    <Behance size={20} />
                    <span>behance.net/samanthaquintero</span>
                  </a>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <input
                    type="text"
                    name="name"
                    value={formState.name}
                    onChange={handleChange}
                    placeholder="NAME"
                    required
                    className="w-full bg-transparent border-b border-bone-white/30 py-2 px-0 font-sans-condensed text-bone-white placeholder:text-bone-white/50 focus:outline-none focus:border-wine-red transition-colors duration-300"
                  />
                </div>
                <div>
                  <input
                    type="email"
                    name="email"
                    value={formState.email}
                    onChange={handleChange}
                    placeholder="EMAIL"
                    required
                    className="w-full bg-transparent border-b border-bone-white/30 py-2 px-0 font-sans-condensed text-bone-white placeholder:text-bone-white/50 focus:outline-none focus:border-wine-red transition-colors duration-300"
                  />
                </div>
                <div>
                  <textarea
                    name="message"
                    value={formState.message}
                    onChange={handleChange}
                    placeholder="MESSAGE"
                    required
                    rows={4}
                    className="w-full bg-transparent border-b border-bone-white/30 py-2 px-0 font-sans-condensed text-bone-white placeholder:text-bone-white/50 focus:outline-none focus:border-wine-red transition-colors duration-300 resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="flex items-center gap-2 bg-transparent border border-wine-red text-wine-red hover:bg-wine-red hover:text-black py-2 px-6 font-sans-condensed tracking-wider transition-colors duration-300"
                >
                  <span>SEND</span>
                  <Send size={16} />
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

