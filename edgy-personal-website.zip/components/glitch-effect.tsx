"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface GlitchEffectProps {
  children: React.ReactNode
}

export function GlitchEffect({ children }: GlitchEffectProps) {
  const [isGlitching, setIsGlitching] = useState(false)

  useEffect(() => {
    // Random glitch effect
    const glitchInterval = setInterval(() => {
      if (Math.random() > 0.7) {
        setIsGlitching(true)
        setTimeout(() => setIsGlitching(false), 200)
      }
    }, 3000)

    return () => clearInterval(glitchInterval)
  }, [])

  return (
    <div className="relative inline-block">
      {/* Original content */}
      <div className={isGlitching ? "opacity-0" : "opacity-100"}>{children}</div>

      {/* Glitch layers */}
      {isGlitching && (
        <>
          <motion.div
            className="absolute top-0 left-0 text-wine-red"
            animate={{
              x: [0, -5, 3, -2, 0],
              opacity: [1, 0.8, 0.9, 0.7, 1],
            }}
            transition={{ duration: 0.2 }}
          >
            {children}
          </motion.div>
          <motion.div
            className="absolute top-0 left-0 text-cyan-300"
            animate={{
              x: [0, 5, -3, 2, 0],
              opacity: [1, 0.8, 0.9, 0.7, 1],
            }}
            transition={{ duration: 0.2 }}
          >
            {children}
          </motion.div>
        </>
      )}
    </div>
  )
}

