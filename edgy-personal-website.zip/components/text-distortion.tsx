"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"

interface TextDistortionProps {
  children: React.ReactNode
}

export function TextDistortion({ children }: TextDistortionProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      animate={{
        filter: isHovered ? "blur(1px) contrast(1.2)" : "blur(0px) contrast(1)",
        color: isHovered ? "rgb(140, 28, 19)" : "rgb(245, 245, 240)",
      }}
      transition={{ duration: 0.3 }}
      className="inline-block"
    >
      {children}
    </motion.div>
  )
}

