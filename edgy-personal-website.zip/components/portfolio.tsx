"use client"

import { useRef, useState } from "react"
import Image from "next/image"
import { motion, useInView } from "framer-motion"

export function Portfolio() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, amount: 0.1 })

  const portfolioItems = [
    {
      id: 1,
      title: "TYPOGRAPHIC CHAOS",
      category: "BRANDING",
      imageUrl: "/placeholder.svg?height=800&width=600",
    },
    {
      id: 2,
      title: "DIGITAL DYSTOPIA",
      category: "POSTER DESIGN",
      imageUrl: "/placeholder.svg?height=800&width=600",
    },
    {
      id: 3,
      title: "NEON NIGHTMARES",
      category: "ALBUM ARTWORK",
      imageUrl: "/placeholder.svg?height=800&width=600",
    },
    {
      id: 4,
      title: "BRUTALIST WEB",
      category: "UI DESIGN",
      imageUrl: "/placeholder.svg?height=800&width=600",
    },
    {
      id: 5,
      title: "ABSTRACT IDENTITY",
      category: "LOGO DESIGN",
      imageUrl: "/placeholder.svg?height=800&width=600",
    },
    {
      id: 6,
      title: "PUNK PUBLICATION",
      category: "EDITORIAL",
      imageUrl: "/placeholder.svg?height=800&width=600",
    },
  ]

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.8 } },
  }

  return (
    <section id="portfolio" className="py-24 md:py-32 relative bg-black/80">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-serif text-4xl md:text-6xl text-bone-white mb-16 relative inline-block">
            PORTFOLIO
            <span className="absolute -bottom-2 left-0 w-1/3 h-0.5 bg-wine-red"></span>
          </h2>

          <motion.div
            ref={ref}
            variants={container}
            initial="hidden"
            animate={isInView ? "show" : "hidden"}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          >
            {portfolioItems.map((item) => (
              <PortfolioItem key={item.id} item={item} />
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}

interface PortfolioItemProps {
  item: {
    id: number
    title: string
    category: string
    imageUrl: string
  }
}

function PortfolioItem({ item }: PortfolioItemProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      variants={item}
      className="group relative overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="aspect-[3/4] relative overflow-hidden">
        <Image
          src={item.imageUrl || "/placeholder.svg"}
          alt={item.title}
          fill
          className="object-cover grayscale group-hover:grayscale-0 transition-all duration-700 transform group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors duration-500" />
      </div>

      <motion.div
        className="absolute inset-0 flex flex-col justify-end p-6"
        animate={{
          y: isHovered ? 0 : 10,
          opacity: isHovered ? 1 : 0.8,
        }}
        transition={{ duration: 0.3 }}
      >
        <span className="text-wine-red font-sans-condensed text-sm tracking-widest mb-2">{item.category}</span>
        <h3 className="font-serif text-2xl md:text-3xl text-bone-white">{item.title}</h3>
      </motion.div>
    </motion.div>
  )
}

