"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { TextDistortion } from "./text-distortion"

export function About() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, amount: 0.3 })

  return (
    <section id="about" className="py-24 md:py-32 relative">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="font-serif text-4xl md:text-6xl text-bone-white mb-12 relative inline-block">
              ABOUT
              <span className="absolute -bottom-2 left-0 w-1/3 h-0.5 bg-wine-red"></span>
            </h2>

            <div className="font-sans-condensed text-lg md:text-xl text-bone-white/90 space-y-6 leading-relaxed">
              <TextDistortion>
                <p>
                  I'm Samantha Quintero, a graphic designer with a passion for creating bold, conceptual visual
                  experiences that challenge conventional aesthetics.
                </p>
              </TextDistortion>

              <p>
                With a background in fine arts and digital design, I've developed a distinctive style that merges
                avant-garde concepts with practical design solutions. My work explores the boundaries between order and
                chaos, finding beauty in unexpected juxtapositions.
              </p>

              <p>
                Featured in Communication Arts, Print Magazine, and AIGA exhibitions, my designs push against the
                mainstream while delivering powerful visual messages. Each project is an opportunity to create something
                that resonates on both intellectual and visceral levels.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

